import os
import numpy as np
import open3d as o3d

data_path="/home/stud/chengl/storage/user/testModels/spaghetti/assets/checkpoints/spaghetti_chairs_large/shapeNetPart/03001627_shape_train"
save_ply= "/home/stud/chengl/storage/user/testModels/spaghetti/assets/checkpoints/spaghetti_chairs_large/shapeNetPart/chair_plys"
for idx, txt_file in enumerate(os.listdir(data_path)):  
    txt_file_path= os.path.join(data_path, txt_file)
    print("shape txt_file_path: ",txt_file_path)
    pcd= np.loadtxt(txt_file_path)

    #analyze the scale of the pcd?



    
    print("shape of pcd:",pcd.shape)
    pcd_o3d = o3d.geometry.PointCloud()
    pcd_o3d.points = o3d.utility.Vector3dVector(pcd) 
    pcd_down=pcd_o3d.farthest_point_down_sample(num_samples=2048)
    pcd_down_points=np.asarray(pcd_down.points)
    print("shape of pcd_down:",pcd_down_points.shape)
    output_file = os.path.join(save_ply, f"{txt_file.split('.')[0]}.ply")
    o3d.io.write_point_cloud(output_file, pcd_down)


    # exit()