import os
import numpy as np
import open3d as o3d


def old_normalize_bounding_box(pcd):
    # Calculate the axis-aligned bounding box
    aabb = pcd.get_axis_aligned_bounding_box()
    
    # Get the center of the bounding box
    aabb_center = aabb.get_center()
    
    # Translate the point cloud to center the bounding box at the origin
    pcd.translate(-aabb_center)
    
    # Calculate extents of the bounding box
    aabb_extent = aabb.get_extent()
    
    # Determine the scaling factor as the reciprocal of the maximum extent
    scale_factor = 1 / np.max(aabb_extent)
    
    # Scale the point cloud to normalize its bounding box to fit within [-1,1]³
    pcd.scale(scale_factor, center=pcd.get_center())

    return pcd

def normalize_bounding_box(pcd):
    # Calculate the axis-aligned bounding box
    aabb = pcd.get_axis_aligned_bounding_box()    
    # Get the center of the bounding box
    aabb_center = aabb.get_center()    
    # Translate the point cloud to center the bounding box at the origin
    pcd.translate(-aabb_center)    
    # Calculate extents of the bounding box
    aabb_extent = aabb.get_extent()    
    # Calculate the norm of the extents vector
    norm_extent = np.linalg.norm(aabb_extent)    
    # Determine the scaling factor as the reciprocal of the norm of the extents
    scale_factor = 1 / norm_extent    
    # Apply the scaling
    pcd.scale(scale_factor, center=[0, 0, 0])  # Scale around the new origin    
    return pcd



mesh_data_path ="/home/stud/chengl/storage/user/testModels/spaghetti/assets/checkpoints/spaghetti_chairs_large/lei_train2/occ"
sampled_data = "/home/stud/chengl/storage/user/testModels/spaghetti/assets/checkpoints/spaghetti_chairs_large/lei_train2/sampled_pcd"
sampled_pcd_normalized_path = "/home/stud/chengl/storage/user/testModels/spaghetti/assets/checkpoints/spaghetti_chairs_large/lei_train2/sampled_pcd_normalized" 
# print("Mesh data path:", mesh_data_path)
# print("Files in directory:", os.listdir(mesh_data_path))

# Step 1: sampling
# for idx, obj in enumerate(os.listdir(mesh_data_path)):  # Unpack the tuple into idx and obj
#     if not obj.endswith(".obj"):  # Now `obj` is the filename, so .endswith will work
#         continue
#     print("obj:", obj)
#     file_path = os.path.join(mesh_data_path, obj)  # Construct the full file path
#     print("show file_path:", file_path)
#     # exit()
#     # sample 2048 points on each mesh
#     mesh = o3d.io.read_triangle_mesh(file_path)

#     if not mesh.has_triangles():
#         print(f"Warning: {obj} does not have valid triangles, skipping.")
#         break

#     sampled_points = mesh.sample_points_poisson_disk(number_of_points=2048, init_factor=5)
#     # points_np = np.asarray(sampled_points.points)
#     output_file = os.path.join(sampled_data, f"sampled_{obj.split('.')[0]}.ply")
#     o3d.io.write_point_cloud(output_file, sampled_points)
    # exit()
# Step 2 normalizing

for idx, ply in enumerate(os.listdir(sampled_data)):  # Unpack the tuple into idx and obj
    
    index= int( (ply.split('.')[0]).split('_')[1])    
    # if index!=41:
    #     continue
    print("see  index:",index)
    file_path = os.path.join(sampled_data, ply) # Construct the full file path
    ply_data = o3d.io.read_point_cloud(file_path)
    # normalize the ply point cloud data 
    points = np.asarray(ply_data.points)
    print("Number of points:", len(ply_data.points))  # Print number of points


    ply_data= normalize_bounding_box(ply_data)


    save_path= os.path.join(sampled_pcd_normalized_path,ply)
    o3d.io.write_point_cloud(save_path, ply_data)

    # if idx==500:
    #     break
    

    # exit()

    # print("ply_data shape:",ply_data.shape)
    # centroid = ply_data.get_center()
    # # Translate the centroid of the point cloud to the origin
    # ply_data.translate(-centroid)
    # # Scale the points so that the maximum distance from the origin is 1
    # max_distance = max(np.linalg.norm(np.asarray(ply_data.points), axis=1))
    # ply_data.scale(1 / max_distance, center=ply_data.get_center())
    # ply_data= normalize_bounding_box(ply_data)
    # Now you can use the normalized point cloud

    
