import numpy as np
import os
import json
# import h5py
import open3d as o3d
from utils_chamfer.model_utils import calc_cd
import torch
from torch.utils.data import Dataset, DataLoader
import datetime

# conda install -c conda-forge gcc=9 gxx=9
# conda install -c conda-forge libxcrypt
# export CFLAGS="-I$CONDA_PREFIX/include"
# export LDFLAGS="-L$CONDA_PREFIX/lib"
# find $CONDA_PREFIX -name crypt.h
# added extra_link_args=['-L/usr/lib/x86_64-linux-gnu/'] in the setup.py file




# open3d.registration.compute_fpfh_feature
class PointCloudDataset(Dataset):
    def __init__(self, root_dir, transform=None):
        """
        Args:
            root_dir (string): Directory with all the .ply files.
            transform (callable, optional): Optional transform to be applied on a sample.
        """
        self.root_dir = root_dir
        self.transform = transform
        self.files = [f for f in os.listdir(root_dir) if f.endswith('.ply')]
        self.files = sorted(self.files, key=self.extract_number)  # Corrected
        # print("sorted files:",self.files)
        # exit()

    def __len__(self):
        return len(self.files)

    def __getitem__(self, idx):
        file_name = self.files[idx]
        file_path = os.path.join(self.root_dir, file_name)
        # Load the point cloud
        pcd = o3d.io.read_point_cloud(file_path)
        # Convert Open3D point cloud to numpy array
        points = np.asarray(pcd.points)

        # Optionally, apply transformations
        if self.transform:
            points = self.transform(points)

        # Convert numpy array to torch tensor
        points = torch.tensor(points, dtype=torch.float32)

        return points

    def extract_number(self, file_name):
        # Assumes file format is 'sampled_XXXX.ply' where XXXX is a number
        base = os.path.basename(file_name)
        number_part = base.split('_')[1]
        number = number_part.split('.')[0]
        return int(number)


def get_dataloader(root_dir, batch_size=32, shuffle=False, num_workers=4):
    """Create the DataLoader for the given directory."""
    dataset = PointCloudDataset(root_dir=root_dir, transform=None)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, num_workers=num_workers)
    file_names = dataset.files  
    return dataloader,file_names

def old_compute_chamfer_loss(A, B):
    try:
        Batch_size,num_points,_dim = A.size()
    except Exception as e:
        print("Error:", e)
        exit()

    batch_size = A.size(0)
    losses = []
    for i in range(batch_size):
        # Mask non-padding points
        mask_A = ~(A[i] == 0).all(dim=-1)
        mask_B = ~(B[i] == 0).all(dim=-1)
        A_filtered = A[i][mask_A]
        B_filtered = B[i][mask_B]
        # Compute Chamfer distance
        A_filtered = A_filtered.unsqueeze(0)
        B_filtered = B_filtered.unsqueeze(0)
        # print("seeing A_filtered shape:", A_filtered.shape) # torch.Size([11000, 3])
        # print("seeing B_filtered shape:", B_filtered.shape) # torch.Size([110000, 3])
        cd_p, cd_t= calc_cd(A_filtered, B_filtered)
        losses.append(cd_t)
    return losses

def compute_chamfer_loss(A, B):
    try:
        batch_size, num_points, _dim = A.size()
    except Exception as e:
        print("Error:", e)
        exit()

    # Mask non-padding points for entire batches
    mask_A = ~(A == 0).all(dim=-1)
    mask_B = ~(B == 0).all(dim=-1)

    # Apply the masks
    A_filtered = A[mask_A].view(batch_size, -1, _dim)
    B_filtered = B[mask_B].view(batch_size, -1, _dim)

    # Compute Chamfer distance for all batch pairs
    cd_p, cd_t = calc_cd(A_filtered, B_filtered)
    return cd_t




device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
correspondent_file_json_path= "./correspondent_file.json"
# spaghetti_data_path= "./spaghetti_data"
# path_shapenetPart= "./shapeNet_part_data"# 1ace72a88565df8e56bd8571ad86331a


path_shapenetPart= "/home/stud/chengl/storage/user/testModels/spaghetti/assets/checkpoints/spaghetti_chairs_large/shapeNetPart/chair_plys"# 1ace72a88565df8e56bd8571ad86331a
spaghetti_data_path= "/home/stud/chengl/storage/user/testModels/spaghetti/assets/checkpoints/spaghetti_chairs_large/lei_train2/sampled_pcd_normalized"


data_loader, file_names= get_dataloader(spaghetti_data_path, batch_size=1000, shuffle=False, num_workers=1)

correspondent_file={}

for idx, shapeNetPart_shape in enumerate(os.listdir(path_shapenetPart)):
    print("idx",idx)
    start_time = datetime.datetime.now()
    anchor_time= start_time
    print("Start Time:", anchor_time.strftime("%Y-%m-%d %H:%M:%S"))
    # print("shapeNetPart_shape",shapeNetPart_shape)
    source_shape_id= shapeNetPart_shape.split(".")[0]
    # exit()
    path_shapenetPart_shape= os.path.join(path_shapenetPart,shapeNetPart_shape)
    shapenetPart_shape= o3d.io.read_point_cloud(path_shapenetPart_shape)
    points_shapeNet_tensor= torch.from_numpy(np.asarray(shapenetPart_shape.points)).float().to(device)
    # data_loader, file_names= get_dataloader(spaghetti_data_path, batch_size=4, shuffle=False, num_workers=1)
    loss_es=[]
    for idx, spaghetti_data in enumerate(data_loader):
        spaghetti_data=spaghetti_data.to(device)
        # if idx == 7:  # Adjust index based on zero-indexing and total samples
        #     print("Batch sample:", spaghetti_data[0][0])
        #     # spaghetti_data= spaghetti_data.to(device)
        #     print("spaghetti_data",spaghetti_data.shape)
        #     points_shapeNet = points_shapeNet_tensor.unsqueeze(0)
        #     print("points_shapeNet_tensor",points_shapeNet.shape)
        #     loss= compute_chamfer_loss(points_shapeNet.repeat(spaghetti_data.shape[0],1,1), spaghetti_data)
        #     for each in loss:
        #         print("each",each.item())
        #     break
        # print("idx",idx)
        spaghetti_data= spaghetti_data.to(device)
        # print("spaghetti_data",spaghetti_data.shape)
        points_shapeNet = points_shapeNet_tensor.unsqueeze(0)
        # print("points_shapeNet_tensor",points_shapeNet.shape)
        loss= compute_chamfer_loss(points_shapeNet.repeat(spaghetti_data.shape[0],1,1), spaghetti_data)
        for each in loss:
            loss_es.append(each.item())
            # print("each",each.item())
        # find the least loss and the corresponding file name
    least_loss = min(loss_es)
    least_loss_idx = loss_es.index(least_loss)
    least_loss_file_name = file_names[least_loss_idx]
    correspondent_file[source_shape_id]= least_loss_file_name

    end_time = datetime.datetime.now()
    # Calculate the duration
    duration = end_time - start_time
    # duration_in_minutes = duration.total_seconds() / 60 
    print("The step took:", duration)


    print("least_loss_file_name",least_loss_file_name)



with open(correspondent_file_json_path, 'w') as json_file:
    json.dump(correspondent_file, json_file)
    








#idx 0
# spaghetti_data torch.Size([1, 2048, 3])
# points_shapeNet_tensor torch.Size([1, 2048, 3])
# each tensor([15.2707], device='cuda:0')
# idx 1
# spaghetti_data torch.Size([1, 2048, 3])
# points_shapeNet_tensor torch.Size([1, 2048, 3])
# each tensor([8.0909], device='cuda:0')
# idx 2
# spaghetti_data torch.Size([1, 2048, 3])
# points_shapeNet_tensor torch.Size([1, 2048, 3])
# each tensor([54.7042], device='cuda:0')
# idx 3
# spaghetti_data torch.Size([1, 2048, 3])
# points_shapeNet_tensor torch.Size([1, 2048, 3])
# each tensor([21.1403], device='cuda:0')
# idx 4
# spaghetti_data torch.Size([1, 2048, 3])
# points_shapeNet_tensor torch.Size([1, 2048, 3])
# each tensor([8.3582], device='cuda:0')
# idx 5
# spaghetti_data torch.Size([1, 2048, 3])
# points_shapeNet_tensor torch.Size([1, 2048, 3])
# each tensor([17.9327], device='cuda:0')
# idx 6
# spaghetti_data torch.Size([1, 2048, 3])
# points_shapeNet_tensor torch.Size([1, 2048, 3])
# each tensor([37.0623], device='cuda:0')
# idx 7
# spaghetti_data torch.Size([1, 2048, 3])
# points_shapeNet_tensor torch.Size([1, 2048, 3])
# each tensor([7.1395], device='cuda:0')

# shapenetPart_shape= o3d.io.read_point_cloud(path_shapenetPart)
# points_shapeNet_tensor= torch.from_numpy(np.asarray(shapenetPart_shape.points)).float().to(device)
# spaghetti_data_file= os.path.join(spaghetti_data_path,"sampled_0041.ply")
# spaghetti_shape= o3d.io.read_point_cloud(spaghetti_data_file)
# points_spaghetti= np.asarray(spaghetti_shape.points)
# points_spaghetti_tensor= torch.from_numpy(points_spaghetti).float().to(device)
# loss= compute_chamfer_loss(points_shapeNet_tensor,points_spaghetti_tensor)
# print("single loss val:",loss[0])# loss val: tensor([1.2502], device='cuda:0')
# print("check the data of points_spaghetti_tensor",points_spaghetti_tensor[0])
# exit()




# spaghetti_data_file= os.path.join(spaghetti_data_path,spaghetti_data)
# spaghetti_shape= o3d.io.read_point_cloud(spaghetti_data_file)
# points_spaghetti= np.asarray(spaghetti_shape.points)
# points_spaghetti_tensor= torch.from_numpy(points_spaghetti).float().to(device)



# print("spaghetti_shape.points.shape",points_spaghetti.shape)
# print("shapenetPart_shape.points.shape",points_shapeNet.shape)
# bbox_spaghetti= spaghetti_shape.get_axis_aligned_bounding_box()
# bbox_shapeNet= shapenetPart_shape.get_axis_aligned_bounding_box()
# extent1 = bbox_spaghetti.get_extent()
# extent2 = bbox_shapeNet.get_extent()
# print("extent1",extent1)
# print("extent2",extent2)
# exit()
# scale1 = 1.0 / np.max(extent1)
# scale2 = 1.0 / np.max(extent2)
