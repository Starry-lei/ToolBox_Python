#!/bin/bash

rm -rf __pycache__/
rm -rf dist/
rm -rf build/
rm -rf emd.egg-info/
rm -rf /mnt/lustre/chenxinyi1/.conda/envs/pt/lib/python3.7/site-packages/emd-0.0.0-py3.7-linux-x86_64.egg/
