# Source: https://github.com/paul007pl/VRCNet/blob/main/utils/model_utils.py
import torch
import math
import os
import sys
import torch.nn as nn
import torch.nn.functional as F

proj_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(os.path.join(proj_dir, "utils/emd"))
# import emd_module as emd
sys.path.append(os.path.join(proj_dir, "utils/ChamferDistancePytorch"))
from .ChamferDistancePytorch.chamfer3D import dist_chamfer_3D
from .ChamferDistancePytorch.fscore import fscore


def len_category_loss(pred_cate, gt_cate):
    # length is the number of non-zeros elements in both pred and gt

    len_pred = torch.sum(pred_cate != 0, dim=1)
    len_gt = torch.sum(gt_cate != 0, dim=1)

    len_loss = (len_pred- len_gt)**2
    return len_loss


def propotional_loss(pred, gt,point_cloud_size_ratio):
    number_points_pred = pred.shape[1]
    number_points_gt = gt.shape[1]
    print("=============>>>>>>>>number_points_pred:", number_points_pred)
    print("=============>>>>>>>>number_points_gt:", number_points_gt)

    ratio_loss = (number_points_pred/number_points_gt - point_cloud_size_ratio)**2
    return ratio_loss


def calc_cd(output, gt, calc_f1=False, f1_threshold=0.0001):
    # print("Type of shape_pc_pints:", output.dtype)
    # print("Type of x_point_cloud:", gt.dtype)
    # exit()


    cham_loss = dist_chamfer_3D.chamfer_3DDist()
    dist1, dist2, _, _ = cham_loss(gt, output)

    # print("Type of dist1:", dist1.dtype)
    # print("Type of dist2:", dist2.dtype)

    cd_p = (torch.sqrt(dist1).mean(1) + torch.sqrt(dist2).mean(1)) / 2
    # cd_t = (dist1.mean(1) + dist2.mean(1))
    cd_t = (dist1.sum(1) + dist2.sum(1))
    if calc_f1:
        f1, _, _ = fscore(dist1, dist2, f1_threshold)
        return cd_p, cd_t, f1
    else:
        return cd_p, cd_t


# def calc_emd(output, gt, eps=0.005, iterations=50):
#     emd_loss = emd.emdModule()
#     dist, _ = emd_loss(output, gt, eps, iterations)
#     emd_out = torch.sqrt(dist).mean(1)
#     return emd_out


def calc_cd_mean(output, gt, calc_f1=False, f1_threshold=0.0001):
    cham_loss = dist_chamfer_3D.chamfer_3DDist()
    dist1, dist2, _, _ = cham_loss(gt, output)
    cd_p = (torch.sqrt(dist1).mean(1) + torch.sqrt(dist2).mean(1)) / 2
    cd_t = (dist1.mean(1) + dist2.mean(1))
    # cd_t = (dist1.sum(1) + dist2.sum(1))
    if calc_f1:
        f1, _, _ = fscore(dist1, dist2, f1_threshold)
        return cd_p, cd_t, f1
    else:
        return cd_p, cd_t